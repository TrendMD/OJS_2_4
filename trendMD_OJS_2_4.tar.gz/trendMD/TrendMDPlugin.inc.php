<?php

/**
 * @file plugins/generic/trendMD/TrendMDPlugin.inc.php
 *
 * Copyright (c) 2017 TrendMD Inc.
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @class TrendMDPlugin
 * @ingroup plugins_generic_trendMD
 *
 * @brief TrendMD plugin class
 */

import('lib.pkp.classes.plugins.GenericPlugin');

class TrendMDPlugin extends GenericPlugin {
	/**
	 * Called as a plugin is registered to the registry
	 * @param $category string Name of category plugin was registered to
	 * @param $path string Plugin path
	 * @return boolean True iff plugin initialized successfully; if false,
	 * 	the plugin will not be registered.
	 */
	function register($category, $path) {
		$success = parent::register($category, $path);
		if (!Config::getVar('general', 'installed') || defined('RUNNING_UPGRADE')) return true;
		if ($success && $this->getEnabled()) {
			// Insert TrendMD code snippet and div to article footer
			HookRegistry::register('Templates::Article::Footer::PageFooter', array($this, 'insertTrendMD'));
		}
		return $success;
	}

	/**
	 * Get the plugin display name.
	 * @return string
	 */
	function getDisplayName() {
		return __('plugins.generic.trendMD.displayName');
	}

	/**
	 * Get the plugin description.
	 * @return string
	 */
	function getDescription() {
		return __('plugins.generic.trendMD.description');
	}

	/**
	 * Extend the {url ...} smarty to support this plugin.
	 * @param $params Smarty template parameters
	 * @param $smarty Smarty template
	 */
	function smartyPluginUrl($params, &$smarty) {
		$path = array($this->getCategory(), $this->getName());
		if (is_array($params['path'])) {
			$params['path'] = array_merge($path, $params['path']);
		} elseif (!empty($params['path'])) {
			$params['path'] = array_merge($path, array($params['path']));
		} else {
			$params['path'] = $path;
		}

		if (!empty($params['id'])) {
			$params['path'] = array_merge($params['path'], array($params['id']));
			unset($params['id']);
		}
		return $smarty->smartyUrl($params, $smarty);
	}

	/**
	 * Set the page's breadcrumbs, given the plugin's tree of items
	 * to append.
	 * @param $isSubclass boolean
	 */
	function setBreadcrumbs($isSubclass = false) {
		$templateMgr =& TemplateManager::getManager();
		$pageCrumbs = array(
			array(
				Request::url(null, 'user'),
				'navigation.user'
			),
			array(
				Request::url(null, 'manager'),
				'user.role.manager'
			)
		);
		if ($isSubclass) $pageCrumbs[] = array(
			Request::url(null, 'manager', 'plugins'),
			'manager.plugins'
		);

		$templateMgr->assign('pageHierarchy', $pageCrumbs);
	}

	/**
	 * Display verbs for the management interface.
	 */
	function getManagementVerbs() {
		$verbs = array();
		if ($this->getEnabled()) {
			$verbs[] = array('settings', __('plugins.generic.trendMD.manager.settings'));
		}
		return parent::getManagementVerbs($verbs);
	}

	/**
	 * Insert TrendMD code snippet and div to article footer
	 * @param $hookName string Name of hook invoking this callback
	 * @param $params array Smarty callback parameters
	 */
	function insertTrendMD($hookName, $params) {
		$smarty =& $params[1];
		$output =& $params[2];

		$journal =& Request::getJournal();
		$journalId = $journal->getId();

		if ($journalId && $this->getSetting($journalId, 'enabled')) {
			$trendMDCode = $this->getSetting($journalId, 'trendMDCode');
			$output .= '<br /><div class="separator"></div>';
			$output .= '<div id="trendmd-suggestions"></div>';
			$output .= $trendMDCode;
		}

		return false;
	}

	/**
	 * Execute a management verb on this plugin
	 * @param $verb string Management verb
	 * @param $args array Additional parameters
	 * @param $message string Result status message
	 * @param $messageParams array Parameters for the message key
	 * @return boolean
	 */
	function manage($verb, $args, &$message, &$messageParams) {
		if (!parent::manage($verb, $args, $message, $messageParams)) return false;

		switch ($verb) {
			case 'settings':
				$templateMgr =& TemplateManager::getManager();
				$templateMgr->register_function('plugin_url', array(&$this, 'smartyPluginUrl'));
				$journal =& Request::getJournal();

				$this->import('TrendMDSettingsForm');
				$form = new TrendMDSettingsForm($this, $journal->getId());
				if (Request::getUserVar('save')) {
					$form->readInputData();
					if ($form->validate()) {
						$form->execute();
						Request::redirect(null, 'manager', 'plugin');
						return false;
					} else {
						$this->setBreadcrumbs(true);
						$form->display();
					}
				} else {
					$this->setBreadcrumbs(true);
					$form->initData();
					$form->display();
				}
				return true;
			default:
				// Unknown management verb
				assert(false);
				return false;
		}
	}
}
?>
