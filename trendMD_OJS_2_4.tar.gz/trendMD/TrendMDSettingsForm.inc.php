<?php

/**
 * @file plugins/generic/trendMD/TrendMDSettingsForm.inc.php
 *
 * Copyright (c) 2017 TrendMD Inc.
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @class TrendMDSettingsForm
 * @ingroup plugins_generic_trendMD
 *
 * @brief Form for journal managers to modify TrendMD plugin settings
 */

import('lib.pkp.classes.form.Form');

class TrendMDSettingsForm extends Form {

	/** @var $journalId int */
	var $journalId;

	/** @var $plugin object */
	var $plugin;

	/**
	 * Constructor
	 * @param $plugin object An instance of the TrendMD plugin
	 * @param $journalId int Current journal context
	 */
	function TrendMDSettingsForm(&$plugin, $journalId) {
		$this->journalId = $journalId;
		$this->plugin =& $plugin;

		parent::Form($plugin->getTemplatePath() . 'settingsForm.tpl');

		$this->addCheck(new FormValidator($this, 'trendMDCode', 'required', 'plugins.generic.trendMD.manager.settings.trendMDCodeRequired'));
		$this->addCheck(new FormValidatorPost($this));
	}

	/**
	 * Display the form.
	 * @see Form::display()
	 */
	function display($request = null, $template = null) {
			$plugin =& $this->plugin;
			$templateMgr =& TemplateManager::getManager($request);

			$templateMgr->assign('trendMDCode', $plugin->getSetting($journalId, 'trendMDCode'));
			parent::display($request, $template);
	}

	/**
	 * Initialize form data.
	 * @see Form::initData()
	 */
	function initData() {
		$journalId = $this->journalId;
		$plugin =& $this->plugin;

		$this->_data = array(
			'trendMDCode' => $plugin->getSetting($journalId, 'trendMDCode')
		);
	}

	/**
	 * Assign form data to user-submitted data.
	 * @see Form::readInputData()
	 */
	function readInputData() {
		$this->readUserVars(array('trendMDCode'));
	}

	/**
	 * Save form settings.
	 * @see Form::execute()
	 */
	function execute() {
		$plugin =& $this->plugin;
		$journalId = $this->journalId;

		$plugin->updateSetting($journalId, 'trendMDCode', trim($this->getData('trendMDCode'), "\"\';"), 'string');
	}
}

?>
