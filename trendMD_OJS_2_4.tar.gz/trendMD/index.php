<?php

/**
 * @defgroup plugins_generic_trendMD
 */

/**
 * @file plugins/generic/trendMD/index.php
 *
 * Copyright (c) 2017 TrendMD Inc.
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @ingroup plugins_generic_trendMD
 * @brief Wrapper for TrendMD plugin.
 *
 */

require_once('TrendMDPlugin.inc.php');
return new TrendMDPlugin();

?>
